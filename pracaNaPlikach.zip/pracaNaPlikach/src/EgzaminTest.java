public class EgzaminTest {
    public static void main(String[] args) {
        System.out.println(Egzamin.zaliczenie("ania bania   3 3.5 4 5 3 nb:4"));
    }
}
