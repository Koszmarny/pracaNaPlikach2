import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.zip.GZIPOutputStream;

public class Compression {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("podaj nazwe pliku: ");
        String file = scan.next();
        try(BufferedOutputStream doKompresji = new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(file)))){

        }catch(IOException e){

        }
    }
}
